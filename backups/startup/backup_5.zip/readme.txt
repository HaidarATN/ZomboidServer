Backup time: 2023-02-16 at 15:42:14 WIB
ServerName: servertest
Current server version:41.78
Current world version:195
World version in this backup is:195