Backup time: 2023-02-20 at 14:21:39 WIB
ServerName: sadDoto
Current server version:41.78
Current world version:195
World version in this backup is:195